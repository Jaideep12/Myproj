<?php

	session_start();
	$usermail = $_SESSION['usermail'];

	$c = new MongoClient();
	$db = $c->msdb;
	$collection = $db->user;


	if(isset($_POST['send']))
	{
		$Receiver = $_POST['Receiver'];
		$Ccreceiver = $_POST['Ccreceiver'];
		$Bccreceiver = $_POST['Bccreceiver'];
		$Subject = $_POST['Subject'];
		$Mail = $_POST['Mail'];
		$Date =  new MongoDate();
		$s_id=rand(1000,9999);
		$flag_s=1;

		$compose = new MongoClient();

		if ($compose)
		{
			$database = $compose->msdb;
			$collection=$database->user;

			if(isset($_POST['datafile']))
			{
				if(!empty($_POST['datafile']))
					 {
						 $path=$_POST['datafile'];
					//		$metadata = array("date" => new MongoDate());
				$grid = $database->getGridFS();
				$grid->storeFile($path, array("date" => new MongoDate(),"To"=>$_POST['Receiver'],"_id"=>$s_id));

			}
		}
	//$fil
      
		$query=array('Receiver'=>$Receiver);
			//checking for existing user
			$count=$collection->findOne($query);

				//Save the New user
				$user_data=array('To'=>$Receiver,'Cc'=>$Ccreceiver,'Bcc'=>$Bccreceiver,'Subject'=>$Subject,'Mail'=>$Mail,'Date'=>	$Date,'obj_id'=>$s_id,'showing'=>$flag_s);
				$collection->update(array('email'=>$usermail),array('$push'=>array('sent'=>$user_data)),array('upsert' => true));
				//Save to inbox of 'To'
				$user_data=array('From'=>$usermail,'Cc'=>$Ccreceiver,'Bcc'=>$Bccreceiver,'Subject'=>$Subject,'Mail'=>$Mail,'Date'=>	$Date,'obj_id'=>$s_id,'showing'=>$flag_s);
				$collection->update(array('email'=>$Receiver),array('$push'=>array('inbox'=>$user_data)),array('upsert' => true));

				//echo "Your mail is sent to ".$Receiver;
				?>
	        		<script>alert('Mail successfully sent !!!');</script>
	       		 <?php
				 header("Location:sent1.php");
		}
	//}
		else
		{
			header("Location:#");
		}

	}
	else if(isset($_POST['cancel']))
	{
		$Receiver = $_POST['Receiver'];
		$Ccreceiver = $_POST['Ccreceiver'];
		$Bccreceiver = $_POST['Bccreceiver'];
		$Subject = $_POST['Subject'];
		$Mail = $_POST['Mail'];
		$Date =  new MongoDate();
		$s_id=rand(1000,9999);
		$flag_s=1;

		$compose = new MongoClient();
		if($compose)
		{
			$database = $compose->msdb;
			$collection=$database->user;
		if(isset($_POST['datafile']))
		{
			if(!empty($_POST['datafile']))
			{
			$path=$_POST['datafile'];
			echo $path;
			$metadata = array("date" => new MongoDate());
			$grid = $database->getGridFS();
			$storedfile=$grid->storeFile($path, array("metadata" => $metadata));
			//$storedfile=$grid->storeFile($path2, array("metadata" => $metadata));
			echo "file has been stored";
			//$grid->storeFile($filepath, array("metadata" => $metadata));
			}	
		}
		//Save the New user
			$user_data=array('To'=>$Receiver,'Cc'=>$Ccreceiver,'Bcc'=>$Bccreceiver,'Subject'=>$Subject,'Mail'=>$Mail,'Date'=>$Date,'obj_id'=>$s_id,'showing'=>$flag_s);
			$collection->update(array('email'=>$usermail),array('$push'=>array('draft'=>$user_data)),array('upsert' => true));
		?>
				<script>alert('Your mail is saved to Drafts.');</script>
			 <?php
			 header("Location:drafts1.php");
		}
	}
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Correo Mail Application</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<!--js-->
<script src="js/jquery-2.1.1.min.js"></script>
<!--icons-css-->
<link href="css/font-awesome.css" rel="stylesheet">
<!--Google Fonts-->
<link href='//fonts.googleapis.com/css?family=Carrois+Gothic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Work+Sans:400,500,600' rel='stylesheet' type='text/css'>
<!--//skycons-icons-->


<script type="text/javascript">
    function Validate() {
        var emailto = document.getElementById("to").value;
        var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        if (!filter.test(emailto)) {
        alert('Please provide a valid email address for To Field');
        return false;
     }

        var emailcc = document.getElementById("cc").value;
        var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        if (!filter.test(emailadd)) {
        alert('Please provide a valid email address for Cc field');
        return false;
      }

      var emailbcc = document.getElementById("bcc").value;
        var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        if (!filter.test(emailbcc)) {
        alert('Please provide a valid email address for Bcc field');
        return false;
      }
      var subject = document.getElementById("sub").value;
        if (subject==null) {
        var retval=confirm('Do you want to send mail without the subject?');
        if(retval==true)
        	return true;
        else{
        return false;
    }
      }
  }
</script>

</head>
<body>
<div class="page-container">
   <div class="left-content">
	   <div class="mother-grid-inner">
            <!--header start here-->

				<div class="header-main">
					<div class="header-left">
							<div class="logo-name">
									<h1>Correo</h1>
									<!--<img id="logo" src="" alt="Logo"/>-->
							</div>
							<div class="search-box">
									<form method="post">
										<input type="text" placeholder="Search..." required="" name="squery">
										<input type="submit" value="" name="search">
									</form>
									<?php
										if (isset($_POST['search'])) {
											$squery=$_POST['squery'];
											header("location:searching2.php?squery=".$squery);
										}

									?>
								</div>
								<!--//end-search-box-->
							<div class="clearfix"> </div>
					</div>


					<div class="header-right">
						<div class="profile_details_left">
								<div class="clearfix"> </div>
							</div>

							<!--notification menu end -->

							<div class="profile_details">
								<ul>
									<li class="dropdown profile_details_drop">
										<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
											<div class="profile_img">
												<!--<span class="prfil-img"><img src="images/p1.png" alt=""></span>-->
												<span class="prfil-img"><i class="fa fa-user fa-4x"></i></span>
												<div class="user-name">
												<p>Welcome</p>
													<p>"<?php echo $_SESSION ['usermail']; ?>"</p>

												</div>
												<i class="fa fa-angle-down lnr"></i>
												<i class="fa fa-angle-up lnr"></i>
												<div class="clearfix"></div>
											</div>
										</a>
										<ul class="dropdown-menu drp-mnu">
											<li> <a href="/correo/dashboard.php"><i class="fa fa-dashboard"></i> Charts</a> </li>
											<li> <a href="/correo/profile1.php"><i class="fa fa-user"></i> Profile</a> </li>
											<li> <a href="/correo/mini_login.php"><i class="fa fa-sign-out"></i> Logout</a> </li>
										</ul>
									</li>
								</ul>
							</div>

							<div class="clearfix"> </div>
						</div>

				     <!--<div class="clearfix"> </div>
				</div>-->
	</div>

<!--heder end here-->
<!-- script-for sticky-nav -->

		<script>
		$(document).ready(function() {
			 var navoffeset=$(".header-main").offset().top;
			 $(window).scroll(function(){
				var scrollpos=$(window).scrollTop();
				if(scrollpos >=navoffeset){
					$(".header-main").addClass("fixed");
				}else{
					$(".header-main").removeClass("fixed");
				}
			 });

		});
		</script>

		<!-- /script-for sticky-nav -->
<!--inner block start here-->

<div class="inner-block" style="padding-left: 30px;">
    <div class="inbox">
    	  <h2 style="padding-left: 30px;">Compose</h2>
					<form method="post">
						<fieldset style="padding-left: 50px;">
							<input type="email" name="Receiver" placeholder=" To" onfocus="on" size="61" id="to" required><br><br>
							<!--<span class = "error"><?php //if($recer2!=1){//echo $recer;}?></span><br><br>-->
							<input type="email" name="Ccreceiver" placeholder=" Cc" size="61" id="cc"><br><br>
			                <!--<span class = "error"><?php //if($ccerr2!=1){//echo $ccerr;}?></span><br><br>-->
							<input type="email" name="Bccreceiver" placeholder=" Bcc" size="61" id="bcc"><br><br>
						    <!--<span class = "error"><?php //if($bccerr2!=1){ //echo $bccerr;}?></span><br><br>-->
							<input type="text" name="Subject" placeholder=" Subject" size="61" id="sub"><br><br>
							<textarea style="resize:none" name="Mail" cols="60" rows="20" placeholder="Compose Mail" required></textarea><br><br>
							<input type="file" name="datafile" size="60"><br><br>
							<button class="submit" name="send" onclick="return Validate()">Send</button>
							<button class="button" name="cancel">Save to Draft</button>
							<button class="button">Cancel</button>
						</fieldset>
					</form>
	</div>

<!--inner block end here-->
<!--copy rights start here-->
<!--
<div class="copyrights">
	 <p>Correo Mail Application</p>
</div>-->
<!--COPY rights end here-->
</div>

<!--slider menu-->
    <div class="sidebar-menu" style="position:fixed;">
		  	<div class="logo"> <a href="#" class="sidebar-icon"> <span class="fa fa-bars"></span> </a> <a href="#"> <span id="logo" ></span>
			      <!--<img id="logo" src="" alt="Logo"/>-->
			  </a> </div>
		    <div class="menu">
		      <ul id="menu" >
		        <li><a href="/correo/compose2.php"><i class="fa fa-envelope"></i><span>Compose</span></li>
		        <li id="menu-home" ><a href="/correo/inbox1.php"><i class="fa fa-inbox"></i><span>Inbox<?php
						$cursor = $collection->find(array("email"=>$usermail));
						$incnt=0;
						foreach($cursor as $u):
							$incnt=count($u['inbox']);
						endforeach;
						$_SESSION['incnt']=$incnt;
				echo "(".$_SESSION['incnt'].")";?></span></a></li>
		        <li><a href="/correo/sent1.php"><i class="fa fa-envelope"></i><span>Sent<?php
						$cursor = $collection->find(array("email"=>$usermail));
						$sentcnt=0;
						foreach($cursor as $u):
							$sentcnt=count($u['sent']);
						endforeach;
						$_SESSION['sentcnt']=$sentcnt;
				echo "(".$_SESSION['sentcnt'].")";?></span></a></li>
		        <li id="menu-comunicacao" ><a href="/correo/drafts1.php"><i class="fa fa-pencil-square-o"></i><span>Drafts<?php
						$cursor = $collection->find(array("email"=>$usermail));
						$drcnt=0;
						foreach($cursor as $u):
							$drcnt=count($u['draft']);
						endforeach;
						$_SESSION['drcnt']=$drcnt;
				echo "(".$_SESSION['drcnt'].")";?></span></a></li>
		        <li id="menu-academico" ><a href="/correo/trash1.php"><i class="fa fa-trash-o"></i><span>Trash<?php
						$cursor = $collection->find(array("email"=>$usermail));
						$trcnt=0;
						foreach($cursor as $u):
							$trcnt=count($u['trash']);
						endforeach;
						$_SESSION['trcnt']=$trcnt;
				echo "(".$_SESSION['trcnt'].")";?></span></a></li>
		      </ul>
		    </div>
	 </div>
	<div class="clearfix"> </div>
</div>

<!--slide bar menu end here-->
<script>
var toggle = true;

$(".sidebar-icon").click(function() {
  if (toggle)
  {
    $(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
    $("#menu span").css({"position":"absolute"});
  }
  else
  {
    $(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
    setTimeout(function() {
      $("#menu span").css({"position":"relative"});
    }, 400);
  }
                toggle = !toggle;
            });
</script>
<!--scrolling js-->
		<script src="js/jquery.nicescroll.js"></script>
		<script src="js/scripts.js"></script>
		<!--//scrolling js-->
<script src="js/bootstrap.js"> </script>
<!-- mother grid end here-->
</body>
</html>
