<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN"
"http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head><title><?php echo $title; ?> :: By KREXPERT</title>
<meta http-equiv="expires" content="0"/>
<meta http-equiv="Content-Language" content="en-us"/>
<meta http-equiv="content-type" content="Text/html;
charset=UTF-8"/>

<meta name="charset"
content="UTF-8"/>
<meta name="distribution" content="Global"/>
<meta name="rating" content="General"/>
<meta name="robots" content="Index,follow"/>
<meta name="revisit-after" content="3 Day"/>
<link rel="shortcut icon" href="favicon.ico"/>
<link rel="stylesheet" href="style.css" type="text/css"/>
</head><body><div class="head" style="padding:10px; text-align:center"><h2>By KREXPERT</h2></div><br>