<?php
session_start();
session_destroy();
unset($_SESSION);
session_regenerate_id(true);
echo $_SESSION['usermail'];
header("Location:mini_login.php");
?>