<?php
if(isset($_POST['send']))
  {
    $email = $_POST['email'];
    $con = new MongoClient();
    //  Select Database
      $db = $con->msdb;
    //  Select Collection
      $collection = $db->user;
  
        $qry = array("email"=>$email);
          
        $result = $collection->findOne($qry);
    if($result['email']==$email)
      {
          require 'PHPMailer/PHPMailerAutoload.php';

          $mail = new PHPMailer;

          $mail->isSMTP();                            // Set mailer to use SMTP
          $mail->Host = 'smtp.gmail.com';             // Specify main and backup SMTP servers
          $mail->SMTPAuth = true;                     // Enable SMTP authentication
          $mail->Username = 'care.careernavigator@gmail.com';          // SMTP username
          $mail->Password = 'cn12345cn'; // SMTP password
          $mail->SMTPSecure = 'tls';                  // Enable TLS encryption, `ssl` also accepted
          $mail->Port = 587;                          // TCP port to connect to

          $mail->setFrom('careernavigator.com', 'Career Navigator');
          $mail->addReplyTo('info@codexworld.com', 'CodexWorld');
          $mail->addAddress($result['email']);   // Add a recipient

          $mail->isHTML(true);  // Set email format to HTML

          $bodyContent = '<h1>Your Password is : </h1>';
          $bodyContent .= $result['password'];

          $mail->Subject = 'Password Recovery';
          $mail->Body = $bodyContent;

          if(!$mail->send()) {
              echo 'Message could not be sent.';
              echo 'Mailer Error: ' . $mail->ErrorInfo;
          }
          else {
              echo 'Message has been sent';
          } 
      
       }
       else {
          ?>
          <script>alert('Oops! No such email found..');</script>
          <?php
       }
}
?>
<!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <title>Flat Login Form 3.0</title>
    
    
    <link rel="stylesheet" href="css/reset.css">

    <link rel='stylesheet prefetch' href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900|RobotoDraft:400,100,300,500,700,900'>
<link rel='stylesheet prefetch' href='http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>

        <link rel="stylesheet" href="css/style.css">

    
    
    
  </head>

  <body>

    
<!-- Form Mixin-->
<!-- Input Mixin-->
<!-- Button Mixin-->
<!-- Pen Title-->
<div class="pen-title">
  <h1>PICT mail server Login</h1>
</div>
<!-- Form Module-->
<div class="module form-module">
  <div class="toggle">

  </div>
  <div class="form">
    <h2>Forgot Password</h2>
    <form method="post">
      <input type="email" placeholder="Email_Id" name="email" /><br><br>
      <button name="send" type="submit">Send</button>
      <!--email searched number found in db.....send random generated cod eto number after clicking return home-- >
    </form>
  </div>
  </div>
</div>
    
    
    
  </body>
</html>
