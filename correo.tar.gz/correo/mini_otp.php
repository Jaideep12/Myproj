
<?php
session_start();
$usermail = $_SESSION['usermail'];

if(isset($_POST['sendotp']))
{

	$m= new MongoClient();
	if($m)
    {
		$db=$m->msdb;
		$collection=$db->user;
		$query=array("email"=>$usermail);
		$fnd=$collection->findOne($query);
		$num=$fnd['reg'];
    }
    echo " <script type='text/javascript'>alert('OTP Send on your number')</script>";
    //header("Location:index.php");
    //header("Location:index.php");
}
if(isset($_POST['goahead']))
{
  header('Location:/correo/inbox1.php');
}
?>
<!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <title>OTP Page</title>


    <link rel="stylesheet" href="css/reset.css">

    <link rel='stylesheet prefetch' href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900|RobotoDraft:400,100,300,500,700,900'>
<link rel='stylesheet prefetch' href='http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>

        <link rel="stylesheet" href="css/style.css">

    <style type="text/css">
    #demo{
      padding-top: 10px;
    }
    </style>


  </head>

  <body>


<!-- Form Mixin-->
<!-- Input Mixin-->
<!-- Button Mixin-->
<!-- Pen Title-->
<div class="pen-title">
  <h1>Correo Login</h1>
</div>
<!-- Form Module-->
<div class="module form-module">
  <div class="toggle">

  </div>
  <div class="form">
    <h2>OTP Verification</h2>
     <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
      <input type="tel" placeholder="<?php echo $num['phone']; ?>">
       <!--<input type="tel" placeholder="<?php //echo $_SESSION['phno']; ?>"</input>-->
      <input type="number" placeholder="OTP"/>
      <button type="submit" name="sendotp">Send</button>
      <div id="demo">
      <button type="submit" name="goahead">Proceed</button>
    </div>
    </form>
  </div>
  </div>
</div>



  </body>
</html>
