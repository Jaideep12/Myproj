<?php 

#To display Error if any on php file
/*ini_set('display_errors',1);*/

#Creating a Session to Access Logined User Details.

session_start();

#Storing value in local variable from Session variable.
$email=$_SESSION['usermail'];

#Connecting Mongodb
$connection = new MongoClient();


#connecting to our database.
$db=$connection->msdb;


#Connection to User Collection.
$collection=$db->user;

#Storing OTP to send through emails and message.
$search=$collection->find();

foreach ($search as $document) 
{
	if($document["email"]==$email)
		{
			$b = ($document["reg"]);
		}
		$otp_password=$document["otp_password"];

		
}



#Sending OTP To Mail

#Mail subject
$otp_subject="OTP For Login";

#Mail Message 
$otp_message="The One Time Password For Login is ".$otp_password." Don't Share it with anyone.";

#Retrieving data from User collection
$search=$collection->find();


foreach ($search as $document) 
{
	#Checking For Email.
	if($document["email"]==$email)
		{
			#Mail Being Sent
			#$result=mail($document["email"],$otp_subject,$otp_message);
			
			#To pass it to message function
			$mobile=$b['phone'];

			#To pass it to message function.
			$email=$document["email"];
		}
}


#OTP being send To Number

//echo $email;
//echo '<br>'.$otp_subject.$otp_message;
#Including API file for sms.
include ('way2sms.php');

#using function
//send_sms('7776974084','E2859R',$mobile,$otp_message);

send_sms('9867093530','jsrm',$mobile,$otp_message);


$alert_message="Mail and Message with OTP had been send to ".substr_replace($email, '',12, -10)." and ".substr_replace($mobile, '',10);

#showing for confirmation.	
echo "<script type='text/javascript'> alert('$alert_message'); location='otp.html';</script>";
die();
 ?>


