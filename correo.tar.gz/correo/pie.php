<?php

$key = 0;

$connection = new MongoClient();
$collection = $connection->mini->User;

$retval = $collection->distinct("Applied.course");

 $rating_data = array(array('Course Name', 'No. of Applications'));

foreach($retval as $a)
  {
  	//echo $retval;
    if(($a))
    {  
        $filter=array('Applied.course' => $retval[$key]);
        
        $b = $collection->find($filter);

        array_push($rating_data, array($retval[$key++],$collection->find($filter)->count()));
    }
  }  
     
 $encoded_data = json_encode($rating_data);

?>


 
<html>
<head>
<script type="text/javascript" src="https://www.google.com/jsapi"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
<script type="text/javascript">
google.load("visualization", "1", {packages:["corechart"]});
google.setOnLoadCallback(drawChart);
function drawChart() 
{
 var data = google.visualization.arrayToDataTable(
 <?php  echo $encoded_data; ?>
 );
 var options = {
  title: "Course-wise user applications:"
 };
 var chart = new google.visualization.PieChart(document.getElementById("employee_piechart"));
 chart.draw(data, options);
}
</script>
<style>
body
{
 margin:0 auto;
 padding:0px;
 text-align:center;
 width:100%;
 font-family: "Myriad Pro","Helvetica Neue",Helvetica,Arial,Sans-Serif;
 background-color:#FAFAFA;
}
#wrapper
{
 margin:0 auto;
 padding:0px;
 text-align:center;
 width:995px;
}
#wrapper h1
{
 margin-top:50px;
 font-size:45px;
 color:#585858;
}
#wrapper h1 p
{
 font-size:18px;
}
#employee_piechart
{
 padding:0px;
 width:600px;
 height:400px;
 margin-left:190px;
}
</style>
</head>
<body>
 <div id="employee_piechart" style="width: 900px; height: 500px;"></div>
</body>
</html>