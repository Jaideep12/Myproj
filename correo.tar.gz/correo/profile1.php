<?php
session_start();
$usermail = $_SESSION['usermail'];


	if(isset($_POST['done']))
	{
		if(!empty($_POST['nwpsswd']))
		{
		$uname = $_POST['fn'].' '.$_POST['mn'].' '.$_POST['ln'];
		$upass = $_POST['nwpsswd'];
		$phno = $_POST['phno'];
		$cnty = $_POST['cnty'];
		$date = new MongoDate();

		$m = new MongoClient();
		$db = $m->msdb;
		$collection = $db->user;

		$qry = array("email" => $usermail);
		$result = $collection->findOne($qry);
		$collection->update(array("reg.email"=>$usermail), array('$set'=>array("reg.user"=>$uname)));
		$collection->update(array("reg.email"=>$usermail), array('$set'=>array("reg.password"=>$upass)));
		$collection->update(array("email"=>$usermail), array('$set'=>array("password"=>$upass)));
		$collection->update(array("reg.email"=>$usermail), array('$set'=>array("reg.phone"=>$phno)));
		$collection->update(array("reg.email"=>$usermail), array('$set'=>array("reg.country"=>$cnty)));
	}
}
?>

<!DOCTYPE HTML>
<html>
<head>
<title>Correo Mail Application</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!--<meta name="keywords" content="Shoppy Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template,
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />-->
<!--<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>-->
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<!--js-->
<script src="js/jquery-2.1.1.min.js"></script>
<!--icons-css-->
<link href="css/font-awesome.css" rel="stylesheet">
<!--Google Fonts-->
<link href='//fonts.googleapis.com/css?family=Carrois+Gothic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Work+Sans:400,500,600' rel='stylesheet' type='text/css'>
<!--//skycons-icons-->


<script type="text/javascript">
    function Validate() {
        var password = document.getElementById("p9").value;
        var confirmPassword = document.getElementById("p10").value;
        if (password != confirmPassword) {
            alert("Passwords do not match.");
            document.getElementById("p9").value = "";
			document.getElementById("p10").value = "";
            return false;

        }
        else
        {
        	location.href = "inbox1.php"
        }
        //return true;
    }
</script>

</head>
<body>
<div class="page-container">
   <div class="left-content">
	   <div class="mother-grid-inner">
            <!--header start here-->

				<div class="header-main">
					<div class="header-left">
							<div class="logo-name">
									<h1>Correo</h1>
									<!--<img id="logo" src="" alt="Logo"/>-->
							</div>
							<!--search-box
								<div class="search-box">
									<form>
										<input type="text" placeholder="Search..." required="">
										<input type="submit" value="">
									</form>
								</div>
								//end-search-box-->
							<div class="clearfix"> </div>
					</div>


					<div class="header-right">
						<div class="profile_details_left">
							<div class="clearfix"> </div>
						</div>

							<!--notification menu end -->

							<div class="profile_details">
								<ul>
									<li class="dropdown profile_details_drop">
										<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
											<div class="profile_img">
												<!--<span class="prfil-img"><img src="images/p1.png" alt=""></span>-->
												<span class="prfil-img"><i class="fa fa-user fa-4x"></i></span>
												<div class="user-name">
												<p>Welcome</p>
													<p>"<?php echo $_SESSION ['usermail']; ?>"</p>

												</div>
												<i class="fa fa-angle-down lnr"></i>
												<i class="fa fa-angle-up lnr"></i>
												<div class="clearfix"></div>
											</div>
										</a>
										<ul class="dropdown-menu drp-mnu">
											<li> <a href="/correo/dashboard.php"><i class="fa fa-cog"></i> Charts</a> </li>
											<li> <a href="/correo/profile1.php"><i class="fa fa-user"></i> Profile</a> </li>
											<li> <a href="/correo/mini_login.php"><i class="fa fa-sign-out"></i>Sign out</a> </li>
										</ul>
									</li>
								</ul>
							</div>

							<div class="clearfix"> </div>
						</div>

				     <!--<div class="clearfix"> </div>
				</div>-->
	</div>

<!--heder end here-->
<!-- script-for sticky-nav -->

		<script>
		$(document).ready(function() {
			 var navoffeset=$(".header-main").offset().top;
			 $(window).scroll(function(){
				var scrollpos=$(window).scrollTop();
				if(scrollpos >=navoffeset){
					$(".header-main").addClass("fixed");
				}else{
					$(".header-main").removeClass("fixed");
				}
			 });

		});
		</script>

		<!-- /script-for sticky-nav -->
<!--inner block start here-->

<div class="inner-block">
    <div class="inbox">
    	  <h2>User Profile</h2>
			<?php

				$usermail = $_SESSION['usermail'];

					$m= new MongoClient();
					$db=$m->msdb;
				$collection=$db->user;
				$query=array("email"=>$usermail);
				$fnd=$collection->findOne($query);
				$num=$fnd['reg'];


			?>

    	  <form method="post">
				        	<table>
							<?php $q=(explode(" ",$num['user']));
							?>
			                <tr>
			                	<td><i class="fa fa-user"></i> First Name</td>
			                	<td> : <input type='text' name='fn' class='enableOnInput mp' disabled='disabled' id="p1" value="<?php echo $q[0];?>" /> <!--<input type="text" name="mn" placeholder="<?php echo $q[0]; ?>" class="mp" id="p1" />-->

								</td>
			                </tr>
			               	<tr>
			                	<td><i class="fa fa-user"></i> Middle Name</td>
			                	<td> : <input type='text' name='mn' class='enableOnInput mp' disabled='disabled' id="p2" value="<?php echo $q[1];?>" /> <!--:<input type="text" name="mn" placeholder="<?php echo $q[1]; ?>" class="mp" id="p2" />--></td>
			                </tr>
			                <tr>
			                	<td><i class="fa fa-user"></i> Last Name</td>
			                	<td> : <input type='text' name='ln' class='enableOnInput mp' disabled='disabled' id="p3" value="<?php echo $q[2];?>" /> <!--:<input type="text" name="ln" placeholder="<?php echo $q[2]; ?>" class="mp" required id="p3"/>--></td>
			                </tr>
			                <tr>
			                	<td><i class="fa fa-envelope"></i> Email Id</td>
			                	<td> : <input type='text' name='email' class='enableOnInput1 mp' disabled='disabled' id="p4" value="<?php echo $num['email'];?>" /> <!--:<input type="email" name="email" placeholder="<?php echo $num['email'];?>" class="mp" required id="p4" />--></td>
			                </tr>
			                <tr>
			                	<td><i class="fa fa-lock"></i> Password</td>
			                	<td> : <input type='password' name='ps' class='enableOnInput mp' disabled='disabled' id="p5" value="<?php echo $num['password'];?>" /> <!--<input type="password" name="pass" placeholder="<?php echo $num['password'];?>" class="mp" required id="p5"/>--></td>
			                </tr>
			                <tr>
			                	<td><i class="fa fa-phone"></i> Phone No</td>
			                	<td> : <input type='text' name='phno' class='enableOnInput mp' disabled='disabled' id="p6" value="<?php echo $num['phone'];?>" /> <!--<input type="tel" name="phno" placeholder="<?php echo $num['phone'];?>" class="mp" required id="p6" />--></td>
			                </tr>
			                <tr>
			                	<td><i class="fa fa-globe"></i> Country</td>
			                	<td> : <input type='text' name='cnty' class='enableOnInput mp' disabled='disabled' id="p8" value="<?php echo $num['country'];?>" /> <!--<input type="text" name="cnty" placeholder="<?php echo $num['country'];?>" class="mp" required id="p8" />--></td>
			                </tr>
			                <tr>
			                	<td></td>
			                	<td><input type="button" value="Edit" name="edit" id="edit"></input>
			                	</td>
			                	<td></td>
			                </tr>
			                <tr id="np" style="display:none;">
			                	<td><i class="fa fa-lock"></i> New Password</td>
			                	<td> : <input type="password" name="nwpsswd" placeholder="New Password" class="mp" id="p9"/></td>
			                </tr>
			                <tr id="cp" style="display:none;">
			                	<td><i class="fa fa-lock"></i>Confirm Password</td>
			                	<td> : <input type="password" name="cfpsswd" placeholder="Confirm Password" class="mp" id="p10"/></td>
			                </tr>
			                <tr>
			                	<td></td>
			                	<td><input type="submit" value="Done" name="done" id="done1" style="display:none;" onclick="return Validate(); ClearFields();">
														<input type="submit" value="Cancle" name="cancle" id="cancle1" style="display:none;" >
												</td>
			                </tr>
			            </table>
			         </form>



			         <script type="text/javascript">
			         		var el  = document.getElementById('edit');
							var p1 = document.getElementById('p1');
							var p2 = document.getElementById('p2');
							var p3 = document.getElementById('p3');
							var p4 = document.getElementById('p4');
							var p5 = document.getElementById('p5');
							var p6 = document.getElementById('p6');
							var p8 = document.getElementById('p8');
							var p9 = document.getElementById('p9');
							var p10 = document.getElementById('p10');
							el.addEventListener('click', function(){
							    p1.disabled = false;
							    p2.disabled = false;
							    p3.disabled = false;
							    p4.disabled = true;
							    p5.disabled = false;
							    p6.disabled = false;
							    p8.disabled = false;
							    p9.disabled = false;
							  	p10.disabled = false;

							    p1.focus(); // set the focus on the editable field
								});

							$("#edit").click(function () {
								    $('#done').toggle();
								    $(this).toggle();
								    $('#np').eq(0).toggle();
								    $('#cp').eq(0).toggle();
								    $('#dd').eq(0).toggle();
										  $('#done1').eq(0).toggle();
											  $('#cancle1').eq(0).toggle();
								});

							$(function(){
							     $('#edit').click(function(){
									$('.enableOnInput').prop('disabled', false);
										//$('#submitBtn').val('Update');
							     });
								});

			         </script>
	</div>

<!--inner block end here-->
<!--copy rights start here-->
<!--
<div class="copyrights">
	 <p>Correo Mail Application</p>
</div>-->
<!--COPY rights end here-->
</div>

<!--slider menu-->
    <div class="sidebar-menu" style="position:fixed;">
		  	<div class="logo"> <a href="#" class="sidebar-icon"> <span class="fa fa-bars"></span> </a> <a href="#"> <span id="logo" ></span>
			      <!--<img id="logo" src="" alt="Logo"/>-->
			  </a> </div>
		    <div class="menu">
		      <ul id="menu" >
		        <li><a href="/correo/compose2.php"><i class="fa fa-envelope"></i><span>Compose</span></li>
		        <li id="menu-home" ><a href="/correo/inbox1.php"><i class="fa fa-inbox"></i><span>Inbox<?php
						$cursor = $collection->find(array("email"=>$usermail));
						$incnt=0;
						foreach($cursor as $u):
							$incnt=count($u['inbox']);
						endforeach;
						$_SESSION['incnt']=$incnt;
				echo "(".$_SESSION['incnt'].")";?></span></a></li>
		        <li><a href="/correo/sent1.php"><i class="fa fa-envelope"></i><span>Sent<?php
						$cursor = $collection->find(array("email"=>$usermail));
						$sentcnt=0;
						foreach($cursor as $u):
							$sentcnt=count($u['sent']);
						endforeach;
						$_SESSION['sentcnt']=$sentcnt;
				echo "(".$_SESSION['sentcnt'].")";?></span></a></li>
		        <li id="menu-comunicacao" ><a href="/correo/drafts1.php"><i class="fa fa-pencil-square-o"></i><span>Drafts<?php
						$cursor = $collection->find(array("email"=>$usermail));
						$drcnt=0;
						foreach($cursor as $u):
							$drcnt=count($u['draft']);
						endforeach;
						$_SESSION['drcnt']=$drcnt;
				echo "(".$_SESSION['drcnt'].")";?></span></a></li>
		        <li id="menu-academico" ><a href="/correo/trash1.php"><i class="fa fa-trash-o"></i><span>Trash<?php
						$cursor = $collection->find(array("email"=>$usermail));
						$trcnt=0;
						foreach($cursor as $u):
							$trcnt=count($u['trash']);
						endforeach;
						$_SESSION['trcnt']=$trcnt;
				echo "(".$_SESSION['trcnt'].")";?></span></a></li>
		      </ul>
		    </div>
	 </div>
	<div class="clearfix"> </div>
</div>

<!--slide bar menu end here-->
<script>
var toggle = true;

$(".sidebar-icon").click(function() {
  if (toggle)
  {
    $(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
    $("#menu span").css({"position":"absolute"});
  }
  else
  {
    $(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
    setTimeout(function() {
      $("#menu span").css({"position":"relative"});
    }, 400);
  }
                toggle = !toggle;
            });
</script>
<!--scrolling js-->
		<script src="js/jquery.nicescroll.js"></script>
		<script src="js/scripts.js"></script>
		<!--//scrolling js-->
<script src="js/bootstrap.js"> </script>
<!-- mother grid end here-->
</body>
</html>
