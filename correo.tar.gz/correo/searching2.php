<?php

	session_start();
	$usermail = $_SESSION['usermail'];
	$trcnt=0;
	$_SESSION['trcnt']=$trcnt;

	$squery=$_GET['squery'];

	$c = new MongoClient();
	$db = $c->msdb;
	$collection = $db->user;

	$cursor = $collection->find(array("email"=>$usermail));

?>
<!DOCTYPE HTML>
<html>
<head>
<title>Correo Mail Application</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!--<meta name="keywords" content="Shoppy Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template,
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<!--<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>-->
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<!--js-->
<script src="js/jquery-2.1.1.min.js"></script>
<!--icons-css-->
<link href="css/font-awesome.css" rel="stylesheet">
<!--Google Fonts-->
<link href='//fonts.googleapis.com/css?family=Carrois+Gothic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Work+Sans:400,500,600' rel='stylesheet' type='text/css'>
<!--//skycons-icons-->
</head>
<body>
<div class="page-container">
   <div class="left-content">
	   <div class="mother-grid-inner">
            <!--header start here-->

				<div class="header-main">
					<div class="header-left">
							<div class="logo-name">
									<h1>Correo</h1>
									<!--<img id="logo" src="" alt="Logo"/>-->
							</div>
							<!--search-box
								<div class="search-box">
									<form method="POST">
										<input type="text" placeholder="Search..." required="" name="search">
										<input type="submit" value="" name="srch">
									</form>
								</div>
								//end-search-box-->
							<div class="clearfix"> </div>
					</div>


					<div class="header-right">
						<div class="profile_details_left">
								<div class="clearfix"> </div>
							</div>

							<!--notification menu end -->

							<div class="profile_details">
								<ul>
									<li class="dropdown profile_details_drop">
										<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
											<div class="profile_img">
												<!--<span class="prfil-img"><img src="images/p1.png" alt=""></span>-->
												<span class="prfil-img"><i class="fa fa-user fa-4x"></i></span>
												<div class="user-name">
												<p>Welcome</p>
													<p>"<?php echo $_SESSION['usermail']; ?>"</p>
																									</div>
												<i class="fa fa-angle-down lnr"></i>
												<i class="fa fa-angle-up lnr"></i>
												<div class="clearfix"></div>
											</div>
										</a>
										<ul class="dropdown-menu drp-mnu">
											<li> <a href="/correo/dashboard.php"><i class="fa fa-dashboard"></i> Charts</a> </li>
											<li> <a href="/correo/profile1.php"><i class="fa fa-user"></i> Profile</a> </li>
											<li> <a href="/correo/mini_login.php"><i class="fa fa-sign-out"></i> Logout</a> </li>
										</ul>
									</li>
								</ul>
							</div>

							<div class="clearfix"> </div>
						</div>

				     <!--<div class="clearfix"> </div>
				</div>-->
	</div>

<!--heder end here-->
<!-- script-for sticky-nav -->

		<script>
		$(document).ready(function() {
			 var navoffeset=$(".header-main").offset().top;
			 $(window).scroll(function(){
				var scrollpos=$(window).scrollTop();
				if(scrollpos >=navoffeset){
					$(".header-main").addClass("fixed");
				}else{
					$(".header-main").removeClass("fixed");
				}
			 });

		});
		</script>

<?php


		$col=$db->user;
$res=$col->aggregate(array('$unwind'=>'$draft'),array('$match'=>array("email"=>$usermail,'$or'=>array(array("draft.To"=>$squery),array("draft.Cc"=>$squery),array("draft.Bcc"=>$squery)))),array('$group'=>array("_id"=>array("a_id"=>'$_id',"To"=>'$draft.To',"Subject"=>'$draft.Subject'))));
$res2=$col->aggregate(array('$unwind'=>'$sent'),array('$match'=>array("email"=>$usermail,'$or'=>array(array("sent.To"=>$squery),array("sent.Cc"=>$squery),array("sent.Bcc"=>$squery)))),array('$group'=>array("_id"=>array("a_id"=>'$_id',"To"=>'$sent.To',"Subject"=>'$sent.Subject'))));
$res3=$col->aggregate(array('$unwind'=>'$inbox'),array('$match'=>array("email"=>$usermail,'$or'=>array(array("inbox.From"=>$squery),array("inbox.Cc"=>$squery),array("inbox.Bcc"=>$squery)))),array('$group'=>array("_id"=>array("a_id"=>'$_id',"From"=>'$inbox.From',"Subject"=>'$inbox.Subject'))));
?>

<div class="inner-block">
    <div class="inbox">
    	 <h2>Searching</h2>
    	 <!--<div class="col-md-4 compose">
    	 </div>-->
    	 <div class="col-md-12 mailbox-content  tab-content tab-content-in">
    	 	<div class="tab-pane active text-style" id="tab1">
	    	 	<div class="mailbox-border">
	               <div class="mail-toolbar clearfix">
				     <div class="float-left">
				        <div class="btn btn_1 btn-default mrg5R">
				           <i class="fa fa-refresh"> </i>
				        </div>

					        <div class="btn btn_1 btn-default mrg5R">
				           		<i class="fa fa-calendar"> </i>
				        	</div>

				        	<div class="btn btn_1 btn-default mrg5R">
				           		<!--<a href="#" class="font-red" title="">-->
				                        <a href="/correo/trash1.php"><i class="fa fa-trash"></i>
				                    </a>
				        	</div> <div class="clearfix"> </div>
				    </div>
	               </div>
	                <table class="table tab-border">
	                    <tbody>
	                    <?php
	                    		$fres=$res['result'];
	                    		foreach($fres as $r)
	                    		{
	                    			foreach ($r as $fr) {
	                    ?>
	                        <tr>
	                            <td class="hidden-xs">
																<input type="checkbox" class="checkbox" name="check_list[]" value="<?php echo $r['_id']; ?>">
	                            </td>
	                            <td class="hidden-xs">
	                                <i class="fa fa-star icon-state-warning"> </i>
	                            </td>
															<td class="hidden-xs" onclick="location.href='search_ret.php?obj_id=<?php echo $r['_id']; ?>';" style="cursor:pointer;">
	                               	<?php echo "draft";?></a>
	                            </td>
															<td onclick="location.href='search_ret.php?obj_id=<?php echo $r['_id']; ?>';" style="cursor:pointer;">
	                                <?php echo $fr['To'];?>
	                            </td>
															<td onclick="location.href='search_ret.php?obj_id=<?php echo $r['_id']; ?>';" style="cursor:pointer;">
	                            	<?php echo $fr['Subject'];?>
	                            </td>
	                        </tr>
	                        <?php
	                        	}
	                        }
	                        ?>

	                    <?php
	                    		$fres=$res2['result'];
	                    		foreach($fres as $r)
	                    		{
	                    			$fr=$r['_id'];
	                    ?>
	                        <tr>
	                            <td class="hidden-xs">
																<input type="checkbox" class="checkbox" name="check_list[]" value="<?php echo $r['_id']; ?>">
	                            </td>
	                            <td class="hidden-xs">
	                                <i class="fa fa-star icon-state-warning"> </i>
	                            </td>
															<td class="hidden-xs" onclick="location.href='search_ret.php?obj_id=<?php echo $r['_id']; ?>';" style="cursor:pointer;">
	                                <?php echo "sent";?>
	                            </td>
															<td onclick="location.href='search_ret.php?obj_id=<?php echo $r['_id']; ?>';" style="cursor:pointer;">
	                                <?php echo $fr['To'];?>
	                            </td>
															<td onclick="location.href='search_ret.php?obj_id=<?php echo $r['_id']; ?>';" style="cursor:pointer;">
	                            	<?php echo $fr['Subject'];?>
	                            </td>
	                        </tr>
	                        <?php
	                        	}
	                        ?>

                    <?php
	                    		$fres=$res3['result'];
	                    		foreach($fres as $r)
	                    		{
	                    			$fr=$r['_id'];
	                    ?>
	                        <tr >
														<td class="hidden-xs">
															<input type="checkbox" class="checkbox" name="check_list[]" value="<?php echo $r['_id']; ?>">
	                            </td>
	                            <td class="hidden-xs">
	                                <i class="fa fa-star icon-state-warning"> </i>
	                            </td>
															<td class="hidden-xs" onclick="location.href='search_ret.php?r_id=<?php echo $r['_id']; ?>';" style="cursor:pointer;">
	                                <?php echo "inbox";?>
	                            </td>
															<td onclick="location.href='search_ret.php?obj_id=<?php echo $r['_id']; ?>';" style="cursor:pointer;">
	                                <?php echo $fr['From'];?>
	                            </td>
															<td onclick="location.href='search_ret.php?obj_id=<?php echo $r['_id']; ?>';" style="cursor:pointer;">
	                            	<?php echo $fr['Subject'];?>
	                            </td>
	                        </tr>
	                        <?php
	                        	}
	                        ?>

	                    </tbody>
											<?php
										?>
	                </table>
	               </div>
               </div>
               <?php

				?>


          <div class="clearfix"> </div>
   </div>
</div>

<!--inner block end here-->
<!--copy rights start here--><!--
<div class="copyrights">
	 <p>Correo Mail Application</p>
</div>-->
<!--COPY rights end here-->
</div>

<!--slider menu-->
    <div class="sidebar-menu" style="position:fixed;">
		  	<div class="logo"> <a href="#" class="sidebar-icon"> <span class="fa fa-bars"></span> </a> <a href="#"> <span id="logo" ></span>
			      <!--<img id="logo" src="" alt="Logo"/>-->
			  </a> </div>
		    <div class="menu">
					<ul id="menu" >
		        <li><a href="/correo/compose2.php"><i class="fa fa-envelope"></i><span>Compose</span></li>
		        <li id="menu-home" ><a href="/correo/inbox1.php"><i class="fa fa-inbox"></i><span>Inbox<?php
						$cursor = $collection->find(array("email"=>$usermail));
						$incnt=0;
						foreach($cursor as $u):
							$incnt=count($u['inbox']);
						endforeach;
						$_SESSION['incnt']=$incnt;
				echo "(".$_SESSION['incnt'].")";?></span></a></li>
		        <li><a href="/correo/sent1.php"><i class="fa fa-envelope"></i><span>Sent<?php
						$cursor = $collection->find(array("email"=>$usermail));
						$sentcnt=0;
						foreach($cursor as $u):
							$sentcnt=count($u['sent']);
						endforeach;
						$_SESSION['sentcnt']=$sentcnt;
				echo "(".$_SESSION['sentcnt'].")";?></span></a></li>
		        <li id="menu-comunicacao" ><a href="/correo/drafts1.php"><i class="fa fa-pencil-square-o"></i><span>Drafts<?php
						$cursor = $collection->find(array("email"=>$usermail));
						$drcnt=0;
						foreach($cursor as $u):
							$drcnt=count($u['draft']);
						endforeach;
						$_SESSION['drcnt']=$drcnt;
				echo "(".$_SESSION['drcnt'].")";?></span></a></li>
		        <li id="menu-academico" ><a href="/correo/trash1.php"><i class="fa fa-trash-o"></i><span>Trash<?php
						$cursor = $collection->find(array("email"=>$usermail));
						$trcnt=0;
						foreach($cursor as $u):
							$trcnt=count($u['trash']);
						endforeach;
						$_SESSION['trcnt']=$trcnt;
				echo "(".$_SESSION['trcnt'].")";?></span></a></li>
		      </ul>		    </div>
	 </div>
	<div class="clearfix"> </div>
</div>
<!--slide bar menu end here-->
<script>
var toggle = true;

$(".sidebar-icon").click(function() {
  if (toggle)
  {
    $(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
    $("#menu span").css({"position":"absolute"});
  }
  else
  {
    $(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
    setTimeout(function() {
      $("#menu span").css({"position":"relative"});
    }, 400);
  }
                toggle = !toggle;
            });
</script>
<!--scrolling js-->
		<script src="js/jquery.nicescroll.js"></script>
		<script src="js/scripts.js"></script>
		<!--//scrolling js-->
<script src="js/bootstrap.js"> </script>
<!-- mother grid end here-->
</body>
</html>
