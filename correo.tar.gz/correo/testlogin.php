
<!DOCTYPE html>
<html >
	<head>
		<meta charset="UTF-8">
		<title>Mail Server</title>

		<link rel="stylesheet" href="css/reset.css">
	    <link rel='stylesheet prefetch' href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900|RobotoDraft:400,100,300,500,700,900'>
		<link rel='stylesheet prefetch' href='http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>
		<link rel="stylesheet" href="css/style.css">

		<style type="text/css">
		#demo2{
			padding-top: 10px;
		}
		</style>

      <script type="text/javascript">
    function Validate() {
        var password = document.getElementById("txtPassword").value;
        var confirmPassword = document.getElementById("txtConfirmPassword").value;
        if (password != confirmPassword) {
            alert("Passwords do not match.");
            return false;
        }
        var emailadd = document.getElementById("emailid").value;
        var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        if (!filter.test(emailadd)) {
        alert('Please provide a valid email address');
        return false;
    }
     var phnum = document.getElementById("num").value;
     var mob = /^[1-9]{1}[0-9]{9}$/;
       if((mob.test(phnum)==false) || (phnum.length!=10))
       {
         alert('Please provide a valid Phone number');
        return false;
       }
       var password= document.getElementById("txtPassword").value;
       var decimal=  /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/;
       if((decimal.test(password)==false))
       {
       	alert('Please provide a valid Password');
        return false;
       }
       var firstn= document.getElementById("first").value;
       var test12=/^[A-Za-z\s]+$/;
       if((test12.test(firstn)==false))
       {
       	alert('Please provide a valid Firstname');
        return false;
    }
    var secondn= document.getElementById("middle").value;
       var test34=/^[A-Za-z\s]+$/;
       if((test34.test(secondn)==false))
       {
       	alert('Please provide a valid middlename');
        return false;
    }
    var thirdn= document.getElementById("last").value;
       var test56=/^[A-Za-z\s]+$/;
       if((test56.test(thirdn)==false))
       {
       	alert('Please provide a valid middlename');
        return false;
    }
    }
</script>
	</head>

	<body>

     <?php
	session_start();

	if(isset($_POST['login']))
	{
		if(!empty($_POST['email']) && !empty($_POST['pass']))
		{
			$email = $_POST['email'];
			$upass = $_POST['pass'];

			$m = new MongoClient();			 // connect to mongodb
			$db = $m->msdb;				     //  Select Database
			$collection = $db->user;		 //  Select Collection

			$qry = array("email" => $email,"password" => $upass);
			$result = $collection->findOne($qry);


    #function to  Generate OTP
$otp=rand(100000,999999);

#Updating the otp with new one on every login.
$collection->update(array("email" => $email),array('$set'=>array('otp_password' => $otp)));

#To check if email is invalid or password.
$flag_email=0;

#To check if email is invalid or password.
$flag_pass=0;

#Retrieving data from database and User Collection.
$search=$collection->find();

#Looking up in User Login info
foreach ($search as $document)
{
	#To match the email from User Collection.
	if($document["email"]==$email)
		{
			#Valid email found.
			$flag_email=1;

			#To match the password with the email respectively.
			if($document["password"]==$upass)
				{
					#Valid password
					$_SESSION['usermail']=$email;
					$flag_pass=1;
					header('Location:otpgeneratedbackup.php');
					die();
				}

		}

}


/*			if($result['email']==$email && $result['password']==$upass)
				{
					$_SESSION['usermail'] = $result['email'];
					//echo "Login Sucessfull...!!";
					header("Location:mini_otp.php");
				}
			else
			{
				?>
				<script>alert('Wrong Details');</script>
				<?php
			}*/
		}
		else
		{
		?>
			<script>alert('Empty Details');</script>
			<?php
		}
	}

	if(isset($_POST['forgot']))
	{
	  header("Location:mini_forgot.php");
	}

	?>


	<?php

	if(isset($_POST['signup']))
	{
		$uname = $_POST['fn'].' '.$_POST['mn'].' '.$_POST['ln'];
		$email = $_POST['email'];
		$upass = $_POST['pass'];
		$phno = $_POST['phno'];
		$gender = $_POST['gender'];
		$cnty = $_POST['cnty'];


		$emailerr=$pherr=$passerr="";
		$regex = '/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/';
		if (!filter_var($email, FILTER_VALIDATE_EMAIL))
		{
		   $emailerr = "Invalid format and please re-enter valid email";
		   ?>
		   <script type="text/javascript">alert('Invalid Email please enter again')</script>
		   <?php
		}
		else if(!preg_match($regex, $email))
		{
		   $emailerr = "Invalid format and please re-enter valid email";
		   ?>
		   		   <script type="text/javascript">alert('Invalid Email please enter again');</script>
		   <?php
		}
		else
		{
		   $emailerr2=1;
		}

		if(!preg_match("/^[0-9]*$/",$phno) || strlen($phno)!= 10)
		{
			$pherr="Invalid phone number please enter again";
			?>
					   <script type="text/javascript">alert('Invalid Phone number please enter again');</script>
			<?php
		}
		else
		{
		   $pherr2=1;
		}

		if (strlen($upass) <= '8')
		{
				$passerr = "Your Password Must Contain At Least 8 Characters!";
				?>
						   <script type="text/javascript">alert('Invalid Password format please enter again');</script>
				<?php
		}
		else if(!preg_match("#[0-9]+#",$upass))
		{
			$passerr = "Your Password Must Contain At Least 1 Number!";
			?>
					   <script type="text/javascript">alert('Invalid Password please enter again');</script>
			<?php
		}
		else if(!preg_match("#[A-Z]+#",$upass))
		{
			$passerr = "Your Password Must Contain At Least 1 Capital Letter!";
			?>
					   <script type="text/javascript">alert('Invalid Password please enter again');</script>
			<?php
		}
		else if(!preg_match("#[a-z]+#",$upass))
		{
			$passerr = "Your Password Must Contain At Least 1 Lowercase Letter!";
			?>
					   <script type="text/javascript">alert('Invalid Password please enter again');</script>
			<?php
		}
		else
		{
		  $passerr2=1;
		}
		//echo "email".$emailerr2;
		//echo "phone".$pherr2;
		//echo "pass".$passerr2;

		// connect to mongodb
		$m= new MongoClient();

		if($m && $emailerr2==1 && $pherr2==1 && $passerr2==1)
		{
			//connecting to database
			$db=$m->msdb;
			//echo "Database 'msdb' selected";

			//connect to specific collection
			$collection=$db->user;
			//echo "Collection sender Selected succsessfully";

			$query=array('email'=>$email);
			//checking for existing user
			$count=$collection->findOne($query);

			if(!count($count))
			{
				//Save the New user
				$user_data=array('email'=>$email,'password'=>$upass,'reg'=>array('user'=>$uname,'email'=>$email,'password'=>$upass,'phone'=>$phno,'gender'=>$gender,'country'=>$cnty),'inbox'=>array(),'sent'=>array(),'draft'=>array(),'trash'=>array());
				$collection->save($user_data);
				//echo "You are successfully registered.";
				?>
				<script>alert('successfully registered ');</script>
				<?php
			}
			else
			{
				echo "Email is already existed.Please register with another Email id!.";
				?>
				<script>alert('error while registering you...');</script>
				<?php
			}

		}
		else
		{
			?>
			<script> alert('Invalid details please enter again');</script>
			<?php
			header("Location:mini_login.php");
		}

	}
?>


    <!-- Form Mixin-->
    <!-- Input Mixin-->
    <!-- Button Mixin-->
    <!-- Pen Title-->
    <div class="pen-title">
      <h1>Correo Mail Login</h1>
    </div>
    <!-- Form Module-->

    <div class="module form-module">
        <div class="toggle"><i class="fa fa-times fa-pencil"></i>                <!-- PENCIL & TIMES SEPERATED -->
                     <!-- PENCIL & TIMES SEPERATED -->
          <div class="tooltip">Register</div>
        </div>

        <div class="form">
          <h2>Login to your account</h2>
              <form method="post">
            <input type="email" name="email" placeholder="Username" required />
            <input type="password" name="pass" placeholder="Password" required />
            <div>
            <button type="submit" name="login">Login</button>
          </div>
          </form>
          <form method="post">
           <div id="demo2">
            <button type="submit" name="forgot">Forgot Password</button>
          </div>
        </form>
        </div>


        <div class="tooltip"></div>

        <div class="form">
            <h2>Create an account</h2>
            <form method="post">
                <input type="text" name="fn" placeholder="Firstname" id="first" required />
                <input type="text" name="mn" placeholder="Middlename" id="middle"/>
                <input type="text" name="ln" placeholder="Lastname"  id="last" required/>
                <input type="email" name="email" placeholder="Email_Id" id="emailid" required />
                
                <input type="password" name="pass" placeholder="Password" id="txtPassword" required/>
                <span class="error" style = "font-size : 10px;">Password should contain a minimum of 8 characters with at least one upper case one lowercase character one digit and one special character</span>
                <br>
                <br>
                <input type="password" name="pass2" placeholder="Confirm Password" id="txtConfirmPassword" required/>

                <input type="tel" name="phno" placeholder="Phone Number" id="num" required/>

                <select name="gender" required>
                  <option selected disabled hidden>Gender</option>
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                </select>
                <input type="text" name="cnty" placeholder="Country" required/>
                <button type="submit" name="signup" onclick="return Validate()" >Register</button>
            </form>
          </div>

        <!--<div class="cta"><a href="<?php //header('Location:forgot1.php'); ?>">Forgot your password?</a></div>-->
    </div>
            <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

            <script src="js/index.js"></script>
  </body>
</html>
