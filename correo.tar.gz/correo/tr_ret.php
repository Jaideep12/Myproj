<!DOCTYPE HTML>
<?php

	session_start();
	$usermail = $_SESSION['usermail'];

?>


<html>
<head>
<title>Correo Mail Application</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<!--js-->
<script src="js/jquery-2.1.1.min.js"></script>
<!--icons-css-->
<link href="css/font-awesome.css" rel="stylesheet">
<!--Google Fonts-->
<link href='//fonts.googleapis.com/css?family=Carrois+Gothic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Work+Sans:400,500,600' rel='stylesheet' type='text/css'>
<!--//skycons-icons-->
</head>
<body>
<div class="page-container">
   <div class="left-content">
	   <div class="mother-grid-inner">
            <!--header start here-->

				<div class="header-main">
					<div class="header-left">
							<div class="logo-name">
									<h1>Correo</h1>
									<!--<img id="logo" src="" alt="Logo"/>-->
							</div>
							<!--search-box-->
								<div class="search-box">
									<form method="post">
										<input type="text" placeholder="Search..." required="" name="squery">
										<input type="submit" value="" name="search">
									</form>
									<?php
										if (isset($_POST['search'])) {
											$squery=$_POST['squery'];
											header("location:searching2.php?squery=".$squery);
										}

									?>
								</div>
								<!--//end-search-box-->
							<!--//end-search-box-->
							<div class="clearfix"> </div>
					</div>


					<div class="header-right">
						<div class="profile_details_left">
								<div class="clearfix"> </div>
							</div>

							<!--notification menu end -->

							<div class="profile_details">
								<ul>
									<li class="dropdown profile_details_drop">
										<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
											<div class="profile_img">
												<!--<span class="prfil-img"><img src="images/p1.png" alt=""></span>-->
												<span class="prfil-img"><i class="fa fa-user fa-4x"></i></span>
												<div class="user-name">
												<p>Welcome</p>
													<p>"<?php echo $_SESSION ['usermail']; ?>"</p>

												</div>
												<i class="fa fa-angle-down lnr"></i>
												<i class="fa fa-angle-up lnr"></i>
												<div class="clearfix"></div>
											</div>
										</a>
										<ul class="dropdown-menu drp-mnu">
											<li> <a href="/correo/dashboard.php"><i class="fa fa-dashboard"></i> Charts</a> </li>
											<li> <a href="/correo/profile1.php"><i class="fa fa-user"></i> Profile</a> </li>
											<li> <a href="/correo/mini_login.php"><i class="fa fa-sign-out"></i> Logout</a> </li>
										</ul>
									</li>
								</ul>
							</div>

							<div class="clearfix"> </div>
						</div>

				     <!--<div class="clearfix"> </div>
				</div>-->
	</div>

<!--heder end here-->
<!-- script-for sticky-nav -->

		<script>
		$(document).ready(function() {
			 var navoffeset=$(".header-main").offset().top;
			 $(window).scroll(function(){
				var scrollpos=$(window).scrollTop();
				if(scrollpos >=navoffeset){
					$(".header-main").addClass("fixed");
				}else{
					$(".header-main").removeClass("fixed");
				}
			 });

		});
		</script>

		<!-- /script-for sticky-nav -->
<!--inner block start here-->

<style type="text/css">
	.inbox2{
		background-color: white;
		text-align: center;
		font-size: 20px;
		line-height: 1.4em;
	}
	td{
		text-align: left; 
		padding-left: 30px; 
	}
</style>


<div class="inner-block">
    <div class="inbox2">
    	  <h2>Mail details</h2>
		  <?php
			$obj_id= $_GET['obj_id'];
			$c = new MongoClient();
			$db = $c->msdb;
			$collection = $db->user;

			$cursor = $collection->find(array("email"=>$usermail));
			foreach($cursor as $u):
				foreach($u['trash'] as $n => $value):
					if($value['obj_id']==$obj_id):
					?>
				<table>		
				<tr>
				<?php if($value['sent']=='2'):  echo "From Draft,<br>";?>
					<td>To:</td><td><?php echo $value['From']."<br>";?></td>
				<?php endif;
						if($value['sent']=='1'):  echo "From Sent,<br>";?>
					<td>To:</td><td><?php echo $value['From']."<br>";?></td>
				<?php endif;
						if($value['sent']=='0'): echo "From Inbox,<br>";
				?>
					<td>From:</td><td><?php echo $value['From']."<br>";?></td>
				<?php endif;?>
				</tr>
				<tr>	
					<td>Date: </td><td><?php echo date('d-M-Y',$value['Date']->sec)?></td><br>
				</tr>
				
					<?php	if($value['Cc']!=""): ?>
				<tr>	<td>Cc:</td><td><?php
						echo $value['Cc']."<br>";
						endif;
					if($value['Bcc']!=""):?>
				</tr>
				<tr><td>Bcc:</td><td><?php
						echo $value['Bcc']."<br>";
						endif;
					?></td>
				</tr>
				<tr>
					<td>Subject:</td><td><?php if($value['Subject']==""):
										echo "No Subject";
										else:
										echo $value['Subject'];
										endif;
					?></td><br>
				</tr>
				<tr>
					<td>Mail:	</td><td><?php echo $value['Mail'];?></td><br>
				</tr>
				</table>
			<?php
						break;
					endif;
				endforeach;
			endforeach;
		  ?>
		  
	</div>
<!--inner block end here-->
<!--copy rights start here-->
<!--
<div class="copyrights">
	 <p>Correo Mail Application</p>
</div>-->
<!--COPY rights end here-->
</div>

<!--slider menu-->
    <div class="sidebar-menu" style="position:fixed;">
		  	<div class="logo"> <a href="#" class="sidebar-icon"> <span class="fa fa-bars"></span> </a> <a href="#"> <span id="logo" ></span>
			      <!--<img id="logo" src="" alt="Logo"/>-->
			  </a> </div>
		    <div class="menu">
		      <ul id="menu" >
		        <li><a href="/correo/compose2.php"><i class="fa fa-envelope"></i><span>Compose</span></li>
		        <li id="menu-home" ><a href="/correo/inbox1.php"><i class="fa fa-inbox"></i><span>Inbox<?php
						$cursor = $collection->find(array("email"=>$usermail));
						$incnt=0;
						foreach($cursor as $u):
							$incnt=count($u['inbox']);
						endforeach;
						$_SESSION['incnt']=$incnt;
				echo "(".$_SESSION['incnt'].")";?></span></a></li>
		        <li><a href="/correo/sent1.php"><i class="fa fa-envelope"></i><span>Sent<?php 
						$cursor = $collection->find(array("email"=>$usermail));
						$sentcnt=0;
						foreach($cursor as $u):
							$sentcnt=count($u['sent']);
						endforeach;
						$_SESSION['sentcnt']=$sentcnt;
				echo "(".$_SESSION['sentcnt'].")";?></span></a></li>
		        <li id="menu-comunicacao" ><a href="/correo/drafts1.php"><i class="fa fa-pencil-square-o"></i><span>Drafts<?php 
						$cursor = $collection->find(array("email"=>$usermail));
						$drcnt=0;
						foreach($cursor as $u):
							$drcnt=count($u['draft']);
						endforeach;
						$_SESSION['drcnt']=$drcnt;
				echo "(".$_SESSION['drcnt'].")";?></span></a></li>
		        <li id="menu-academico" ><a href="/correo/trash1.php"><i class="fa fa-trash-o"></i><span>Trash<?php 
						$cursor = $collection->find(array("email"=>$usermail));
						$trcnt=0;
						foreach($cursor as $u):
							$trcnt=count($u['trash']);
						endforeach;
						$_SESSION['trcnt']=$trcnt;
				echo "(".$_SESSION['trcnt'].")";?></span></a></li>
		      </ul>
		    </div>
	 </div>
	<div class="clearfix"> </div>
</div>

<!--slide bar menu end here-->
<script>
var toggle = true;

$(".sidebar-icon").click(function() {
  if (toggle)
  {
    $(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
    $("#menu span").css({"position":"absolute"});
  }
  else
  {
    $(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
    setTimeout(function() {
      $("#menu span").css({"position":"relative"});
    }, 400);
  }
                toggle = !toggle;
            });
</script>
<!--scrolling js-->
		<script src="js/jquery.nicescroll.js"></script>
		<script src="js/scripts.js"></script>
		<!--//scrolling js-->
<script src="js/bootstrap.js"> </script>
<!-- mother grid end here-->
</body>
</html>
