<?php
   // connect to mongodb
   $m = new MongoClient();
   echo "Connection to database successfully";

   // select a database
   $db = $m->msdb;
   echo "Database mydb selected";
   $collection = $db->user;
   echo "Collection selected succsessfully";

   // now update the document
   $collection->update(array("country"=>"IND"), array('$set'=>array("country"=>"India")));
   echo "Document updated successfully";

   // now display the updated document
   $cursor = $collection->find();

   // iterate cursor to display title of documents
   echo "Updated document";

   foreach ($cursor as $document) {
      echo "country :"  .$document["country"] . "\n";
   }
?>
